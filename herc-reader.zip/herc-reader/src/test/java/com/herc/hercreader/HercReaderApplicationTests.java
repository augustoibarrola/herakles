package com.herc.hercreader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HercReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.herc.hercreader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HercReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(HercReaderApplication.class, args);
	}

}
